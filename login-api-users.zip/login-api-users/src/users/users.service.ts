import { Injectable, Inject } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './user.entity';

@Injectable()
export class UsersService {

    constructor(@InjectRepository(User) private usersRepository: Repository<User>) { }

    // async getUsers(user: User): Promise<User[]> {
    //     return await this.usersRepository.find();
    // }
     async getAll(): Promise<User[]> {
        return await this.usersRepository.find();
    }


    // async getAll(): Promise<User[]> {
    //     return [
    //         { id: 1, username: "Tarefa 1", password: "false" ,email:"@algumacoisa.com",},
    //         { id: 2, username: "Tarefa 2", password: "false", email:"@heythere.com"}
    //     ];
    // }

    async getUser(_id: number): Promise<User[]> {
        return await this.usersRepository.find({
            select: ["username", "password", "email"],
            where: [{ "id": _id }]
        });
    }


    async updateUser(user: User) {
        return this.usersRepository.save(user);
    }

    async createUser(user: User) {
        return this.usersRepository.save(user);
    }

    async deleteUser(user: User) {
        return this.usersRepository.delete(user);
    }
}